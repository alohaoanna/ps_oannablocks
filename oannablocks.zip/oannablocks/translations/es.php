<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{oannablocks}prestashop>item_bff59c310e5dbc40ad00567a3cf8d103'] = 'Compra ahora';
$_MODULE['<{oannablocks}prestashop>item_d59048f21fd887ad520398ce677be586'] = 'Aprende más';
